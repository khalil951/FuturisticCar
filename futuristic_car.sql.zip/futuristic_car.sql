-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 11 déc. 2022 à 17:18
-- Version du serveur : 10.4.25-MariaDB
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `futuristic_car`
--

-- --------------------------------------------------------

--
-- Structure de la table `car`
--

CREATE TABLE `car` (
  `car_id` int(11) NOT NULL,
  `registration_number` int(11) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `userid` int(11) NOT NULL,
  `state` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `car`
--

INSERT INTO `car` (`car_id`, `registration_number`, `brand`, `model`, `userid`, `state`) VALUES
(26, 12, '3434', 'ywyw', 11, 'gabes'),
(28, 12, 'kia', 'bmw', 112, 'tunis'),
(29, 12, 'kia', 'bmw', 112, 'tunis');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`category_id`, `name`) VALUES
(1, 'Mercedes'),
(2, 'Ferrari'),
(3, 'BMW'),
(4, 'Audi');

-- --------------------------------------------------------

--
-- Structure de la table `mechanic`
--

CREATE TABLE `mechanic` (
  `idm` int(11) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `mechanic`
--

INSERT INTO `mechanic` (`idm`, `lname`, `fname`, `phone`) VALUES
(1, 'anas', 'titouuuuuuuuuuu', 911827178),
(10, 'mojaat', 'meriem', 922495660),
(12, 'ganedi', 'anas', 911827178),
(13, 'anas', 'gnedi', 911827178),
(14, 'anas', 'gnedi', 911827178),
(15, 'anas', 'gnedi', 911827178),
(16, 'anas', 'anas', 922495660);

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `oid` bigint(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`oid`, `date`, `name`, `email`) VALUES
(1, '2022-11-16 11:28:50', 'rania', 'raniasouei@gmail.com'),
(2, '2022-11-16 11:48:55', 'rania', 'raniasouei@gmail.com'),
(3, '2022-11-23 11:18:01', 'username', 'username@domain.com'),
(4, '2022-11-23 11:18:52', 'yosr lassoued', 'yosrlassoued@esprit.tn'),
(5, '2022-11-23 11:37:19', 'youssef kharroubi', 'youssefkharroubi@esprit.tn'),
(6, '2022-11-23 12:07:29', 'rania souei', 'raniasouei@esprit.tn'),
(9, '2022-11-24 12:18:33', 'aziz ouertatani', 'aziz.ouertatani@esprit.tn'),
(10, '2022-11-24 17:14:46', 'mariem mojaat', 'mariem.mojaat@esprit.tn'),
(11, '2022-11-29 15:58:16', 'rania souei', 'raniasouei@esprit.tn'),
(12, '2022-11-29 18:02:44', 'oussema Ben Amor', 'oussemabenamor@esprit.tn'),
(13, '2022-11-29 18:51:56', 'nour amorri', 'nouramorri@esprit.tn'),
(14, '2022-12-01 18:43:34', 'rania souei', 'rania.souei@gmail.com'),
(15, '2022-12-01 18:57:06', 'rania souei', 'rania.souei@gmail.com'),
(16, '2022-12-01 18:58:17', 'rania souei', 'rania.souei@gmail.com'),
(17, '2022-12-05 18:46:16', 'rania souei', 'rania.souei@gmail.com'),
(18, '2022-12-05 20:12:04', 'rania souei', 'rania.souei@gmail.com'),
(19, '2022-12-06 04:58:59', 'rania souei', 'rania.souei@gmail.com'),
(20, '2022-12-06 19:56:37', 'rania souei', 'rania.souei@gmail.com'),
(21, '2022-12-06 19:59:25', 'rania souei', 'rania.souei@gmail.com'),
(22, '2022-12-06 20:00:11', 'rania souei', 'rania.souei@gmail.com'),
(23, '2022-12-07 10:57:10', 'rania souei', 'rania.souei@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `orders_items`
--

CREATE TABLE `orders_items` (
  `oid` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `orders_items`
--

INSERT INTO `orders_items` (`oid`, `name`, `price`, `qty`) VALUES
(1, 'front headlights', '135.00', 1),
(2, 'battery', '400.00', 1),
(2, 'radiator', '350.00', 2),
(3, 'battery', '400.00', 1),
(3, 'front headlights', '135.00', 1),
(4, 'battery', '400.00', 1),
(5, 'battery', '400.00', 1),
(5, 'front headlights', '135.00', 2),
(6, 'battery', '400.00', 1),
(6, 'front headlights', '135.00', 1),
(7, 'battery', '400.00', 2),
(8, 'front headlights', '135.00', 1),
(9, 'battery', '400.00', 2),
(10, 'radiator', '350.00', 1),
(10, 'wheels', '1200.00', 2),
(11, 'front headlights', '135.00', 2),
(12, 'battery', '400.00', 3),
(12, 'front headlights', '135.00', 1),
(13, 'battery', '400.00', 1),
(14, 'front headlights', '135.00', 1),
(15, 'front headlights', '135.00', 1),
(16, 'front headlights', '135.00', 1),
(17, 'front headlights', '135.00', 3),
(18, 'battery', '400.00', 1),
(18, 'front headlights', '135.00', 1),
(19, 'battery', '400.00', 1),
(19, 'front headlights', '135.00', 1),
(19, 'radiator', '350.00', 1),
(20, 'battery', '400.00', 1),
(20, 'front headlights', '135.00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `imageproduct` varchar(200) NOT NULL,
  `nameproduct` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `stock_qty` int(11) NOT NULL,
  `descriptionProduct` text NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`product_id`, `imageproduct`, `nameproduct`, `price`, `stock_qty`, `descriptionProduct`, `brand`, `category_id`) VALUES
(141, 'https://cdn.carbuzz.com/gallery-images/840x560/1066000/100/1066186.jpg', 'steering wheel', 1800, 50, 'brand new car ', 'Audi', 4),
(142, 'https://cdn.carbuzz.com/gallery-images/840x560/1066000/200/1066228.jpg', 'engine', 7000, 75, 'powerful engine by fuel', 'BMW', 3),
(143, 'https://cdn.carbuzz.com/gallery-images/840x560/1067000/200/1067252.jpg', 'Audi R8 GT', 9500, 85, 'splendid cool design', 'Audi', 4),
(144, 'https://cdn.carbuzz.com/gallery-images/840x560/1066000/200/1066226.jpg', 'wheels', 800, 20, 'resilient wheels with powerful rotation', 'Ferrari', 2),
(146, 'https://cdn.carbuzz.com/gallery-images/840x560/1066000/200/1066225.jpg', 'seat', 2000, 12, 'stylish black and red', 'Audi', 4),
(147, 'https://cdn.carbuzz.com/gallery-images/840x560/1066000/100/1066190.jpg', 'gear box', 6000, 75, 'great speed', 'Ferrari', 2),
(149, 'https://www.notebookcheck.net/fileadmin/Notebooks/News/_nc3/Mercedes_Benz.jpg', 'Leather Audi saloon', 2500, 30, 'Mercedes has revealed the interior of the 2023 EQS SUV ahead of the vehicle’s April launch.', 'Mercedes', 1);

-- --------------------------------------------------------

--
-- Structure de la table `response`
--

CREATE TABLE `response` (
  `idresponse` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `text_response` varchar(255) NOT NULL,
  `review_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `review_table`
--

CREATE TABLE `review_table` (
  `review_id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_rating` int(11) NOT NULL,
  `user_review` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Date_rev` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `review_table`
--

INSERT INTO `review_table` (`review_id`, `username`, `email`, `user_rating`, `user_review`, `Date_rev`) VALUES
(14, 'leila', 'leila.benabdallah@gmail.com', 9, 'it\'s a fatastic car and I recommend it', '2022-12-11 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `User_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`User_id`, `Name`, `Last_Name`, `User_Name`, `Password`, `Role`) VALUES
(1, 'khalil', 'oueslati', 'khalilos', 'ccwcwcew', 'admin'),
(2, 'yomna', 'oueslati', 'yomos', 'cwcw', 'admin'),
(3, 'kamel', 'oueslati', 'kmelos', 'cwcw', 'admin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`car_id`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Index pour la table `mechanic`
--
ALTER TABLE `mechanic`
  ADD PRIMARY KEY (`idm`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `name` (`name`),
  ADD KEY `email` (`email`),
  ADD KEY `date` (`date`);

--
-- Index pour la table `orders_items`
--
ALTER TABLE `orders_items`
  ADD PRIMARY KEY (`oid`,`name`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Index pour la table `response`
--
ALTER TABLE `response`
  ADD PRIMARY KEY (`idresponse`),
  ADD KEY `test` (`iduser`),
  ADD KEY `hey` (`review_id`);

--
-- Index pour la table `review_table`
--
ALTER TABLE `review_table`
  ADD PRIMARY KEY (`review_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `car`
--
ALTER TABLE `car`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT pour la table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT pour la table `mechanic`
--
ALTER TABLE `mechanic`
  MODIFY `idm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT pour la table `response`
--
ALTER TABLE `response`
  MODIFY `idresponse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `review_table`
--
ALTER TABLE `review_table`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `response`
--
ALTER TABLE `response`
  ADD CONSTRAINT `hey` FOREIGN KEY (`review_id`) REFERENCES `response` (`idresponse`),
  ADD CONSTRAINT `test` FOREIGN KEY (`iduser`) REFERENCES `response` (`idresponse`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
